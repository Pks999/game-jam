extends Node

var dig_map = []

func _ready():
	for i in range(17):
		dig_map.append(randi_range(0, 1))
